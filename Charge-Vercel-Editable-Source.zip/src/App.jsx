import {
  ArrowDown,
  ArrowRight,
  BatteryCharging,
  Bike,
  Clock3,
  Coffee,
  CreditCard,
  GraduationCap,
  MapPin,
  Music2,
  RotateCcw,
  Sparkles,
  Zap,
} from "lucide-react";
import ChargeMachineStory from "./components/ChargeMachineStory";

const steps = [
  {
    icon: CreditCard,
    title: "Tap to start",
    body: "Find a Charge station and tap a contactless card or phone to begin your rental.",
    note: "Tap to pay",
  },
  {
    icon: BatteryCharging,
    title: "Grab & keep moving",
    body: "Take a slim power bank with you and charge while you walk, study, eat, or hang out.",
    note: "Power in your pocket",
  },
  {
    icon: RotateCcw,
    title: "Return when done",
    body: "Slide it into an open slot at a participating Charge station. It is ready for the next person.",
    note: "Simple return",
  },
];

const moments = [
  {
    time: "8:30 AM",
    icon: Coffee,
    title: "Study session",
    body: "Your laptop is fine. Your phone is at 11%.",
  },
  {
    time: "2:10 PM",
    icon: GraduationCap,
    title: "Class to class",
    body: "Maps, messages, Canvas—still hours to go.",
  },
  {
    time: "7:00 PM",
    icon: Music2,
    title: "The main event",
    body: "Photos, tickets, friends. Do not leave early for an outlet.",
  },
];

const letters = [
  ["C", "City-ready", "Designed for everyday urban life"],
  ["H", "Hassle-free", "Clear from tap to return"],
  ["A", "Anytime power", "For the moments battery runs low"],
  ["R", "Rent in seconds", "A quick, familiar flow"],
  ["G", "Grab & go", "Charge without staying by an outlet"],
  ["E", "Easy return", "Back into a participating station"],
];

function Brand() {
  return (
    <a className="brand" href="#top">
      <span className="brand-mark">
        <Zap size={17} strokeWidth={2.7} />
      </span>
      CHARGE
    </a>
  );
}

export default function App() {
  return (
    <main>
      <header className="site-header">
        <Brand />
        <nav aria-label="Primary navigation">
          <a href="#how">How it works</a>
          <a href="#campus">Where it fits</a>
          <a href="#why">Why Charge</a>
        </nav>
        <a className="header-pill" href="#how">
          Meet Charge <ArrowRight size={15} />
        </a>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">
            <span /> Seattle concept · UW pilot first
          </p>
          <h1>
            Your phone
            <br />
            is dying.
            <br />
            <em>Your day isn’t.</em>
          </h1>
          <p className="hero-lede">
            Charge is shared power for life on the move. Tap to rent a portable
            charger, power up as you go, and return it to a participating
            station.
          </p>
          <div className="hero-actions">
            <a className="button button-primary" href="#how">
              Show me how <ArrowDown size={18} />
            </a>
            <span className="concept-chip">
              <Sparkles size={15} /> Starting at UW · Built for Seattle
            </span>
          </div>
          <p className="hero-note">
            Not a live rental service yet. This page introduces the planned
            experience.
          </p>
        </div>
        <div className="hero-image">
          <img
            src="/charge-hero.webp"
            alt="Seattle students using a portable power bank station at an outdoor gathering"
          />
          <div className="image-top-card">
            <MapPin size={16} /> Seattle, Washington
          </div>
          <div className="low-battery-card">
            <div>
              <span>PHONE BATTERY</span>
              <strong>8%</strong>
            </div>
            <div className="battery-line">
              <span />
            </div>
            <p>
              <BatteryCharging size={18} /> Charge the phone. Keep the plans.
            </p>
          </div>
        </div>
      </section>

      <section className="ticker" aria-label="Charge product summary">
        <span>TAP</span>
        <Zap size={16} />
        <span>BORROW</span>
        <Zap size={16} />
        <span>CHARGE ANYWHERE</span>
        <Zap size={16} />
        <span>RETURN</span>
      </section>
      <ChargeMachineStory />

      <section className="explain section-shell">
        <div className="explain-icon">
          <Bike size={29} />
        </div>
        <p>Think bike share—</p>
        <h2>
          except what you borrow fits in your pocket and keeps your phone alive.
        </h2>
      </section>

      <section className="how section-shell" id="how">
        <div className="section-heading">
          <div>
            <p className="kicker">How it works</p>
            <span className="section-index">01 / THE BASICS</span>
          </div>
          <h2>
            Three steps.
            <br />
            No cable hunt.
          </h2>
          <p>
            Charge is designed to feel familiar even if you have never used a
            shared power bank before.
          </p>
        </div>
        <div className="steps-grid">
          {steps.map(({ icon: Icon, title, body, note }, i) => (
            <article className="step-card" key={title}>
              <div className="step-top">
                <span>0{i + 1}</span>
                <span className="step-icon">
                  <Icon size={24} strokeWidth={1.8} />
                </span>
              </div>
              <div>
                <h3>{title}</h3>
                <p>{body}</p>
              </div>
              <small>{note}</small>
            </article>
          ))}
        </div>
        <p className="detail-note">
          Exact rental and payment details will be confirmed during pilot
          development.
        </p>
      </section>

      <section className="campus" id="campus">
        <div className="campus-intro section-shell">
          <div className="section-heading light-heading">
            <div>
              <p className="kicker">Built for Seattle days</p>
              <span className="section-index">02 / THE MOMENTS</span>
            </div>
            <h2>
              One long day.
              <br />A lot of battery.
            </h2>
            <p>
              UW is the first pilot community—not the finish line. Charge
              belongs anywhere people gather, move, and stay awhile.
            </p>
          </div>
          <div className="moments-grid">
            {moments.map(({ time, icon: Icon, title, body }) => (
              <article key={time}>
                <div className="moment-top">
                  <time>{time}</time>
                  <Icon size={22} />
                </div>
                <div>
                  <h3>{title}</h3>
                  <p>{body}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="why section-shell" id="why">
        <div className="why-title">
          <p className="kicker">What CHARGE stands for</p>
          <h2>
            A name that
            <br />
            <em>explains itself.</em>
          </h2>
          <p>
            Not six corporate slogans—six promises that keep the experience
            simple for first-time users.
          </p>
        </div>
        <div className="letter-grid">
          {letters.map(([letter, title, body]) => (
            <article key={letter}>
              <span>{letter}</span>
              <div>
                <h3>{title}</h3>
                <p>{body}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="venues section-shell">
        <div className="venue-label">
          <Clock3 size={18} /> Future venue partners
        </div>
        <div className="venue-content">
          <h2>
            Useful for students.
            <br />
            Simple for places.
          </h2>
          <div>
            <p>
              Charge is exploring future stations around campus events and
              nearby gathering places. A compact station could give guests a
              practical amenity without pretending the pilot is already live.
            </p>
            <div className="venue-tags">
              <span>Campus events</span>
              <span>Cafés</span>
              <span>Student spaces</span>
            </div>
          </div>
        </div>
      </section>

      <section className="final-cta">
        <p className="kicker">Starting at UW. Built beyond campus.</p>
        <h2>
          Power should be
          <br />
          <em>where life happens.</em>
        </h2>
        <a className="button button-dark" href="#top">
          Meet Charge <ArrowRight size={18} />
        </a>
        <small>
          Consumer marketing demo · No live stations, pricing, or launch date
          claimed.
        </small>
      </section>
      <footer>
        <Brand />
        <p>
          Shared power for Seattle life.
          <br />
          <span>UW pilot community · Concept 2026</span>
        </p>
        <div>
          <a href="#how">How it works</a>
          <a href="#campus">Where it fits</a>
          <a href="#why">Why Charge</a>
        </div>
      </footer>
    </main>
  );
}
